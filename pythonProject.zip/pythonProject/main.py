from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
import json

# from Models import *;

import Models


def create_session():

    # Replace the placeholders with your actual server, database, and driver information
    # server = "BIRL-107098DT\\SQLEXPRESS"  # Replace with your SQL Server instance name or IP address
    # database = "PythonDatabase"  # Replace with your database name
    # driver = "ODBC Driver 17 for SQL Server"  # Use the appropriate ODBC driver for your environment
    # driver = "SQL Server Native Client 11.0"
    # Connection string for Windows authentication
    # connection_string = (
    #     f'mssql+pyodbc://{server}/{database}?driver=ODBC+Driver+17+for+SQL+Server;Trusted_Connection=yes'
    # )

    connection_string = (
    'mssql+pyodbc://BIRL-107098DT\\SQLEXPRESS/DbPython?trusted_connection=yes&driver=ODBC+Driver+17+for+SQL+Server'
)

    # MySQL server details
    # user = "root"  # MySQL username
    # password = "root123456789"  # MySQL password
    # host = "localhost"  # MySQL server hostname
    # port = "3306"  # MySQL server port
    # database = "jsondb"  # MySQL database name

    # # Connection string for MySQL
    # connection_string = f"mysql+pymysql://{user}:{password}@{host}:{port}/{database}"

    engine = create_engine(connection_string)
    Session = sessionmaker(bind=engine)
    session = Session()
    return session


def create_db_model(obj, className, parrentClass=None, parrentID=None):
    try:
        nestedObjects = []
        objectLists = []

        model = getattr(Models, className)
        model_instance = model()

        for key, value in obj.items():
            if isinstance(value, dict):
                nestedObjects.append(key)
            elif isinstance(value, list) and value:
                objectLists.append(key)
            else:
                setattr(model_instance, key, value)

        if parrentClass and parrentID:
            setattr(model_instance, f"{parrentClass}_id", parrentID)

        # Add Object to database
        session = create_session()
        session.add(model_instance)
        session.commit()
    except Exception as e:
        print(f"Error occurred while inserting object into {className} table: {e}")



    for key in nestedObjects:
        create_db_model(obj[key], key, className, model_instance.id)

    for key in objectLists:
        for item in obj[key]:
            create_db_model(item, key, className, model_instance.id)


def main():

    # Read JSON data from a file
    with open("schema.json", "r") as file:
        json_data = json.load(file)

    create_db_model(json_data[0], "tradeflow")

    session = create_session()
    query = session.query(Models.tradeflow).filter(Models.tradeflow.id == 5)
    results = query.all()

    if results:
            print(results[0])
    else:
         print("No results found.")


if __name__ == "__main__":
    main()
