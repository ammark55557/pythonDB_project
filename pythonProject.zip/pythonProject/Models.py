from sqlalchemy import Column, Integer, Text, Boolean, Float, ForeignKey
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import relationship

Base = declarative_base()


class tradeflow(Base):
    __tablename__ = "tradeflow"
    id = Column(Integer, primary_key=True, autoincrement=True)
    hash = Column(Text)
    tradeflow_id = Column(Integer)
    type = Column(Text)
    message_generated_event_date = Column(Text)
    type_x_tradeflow_id = Column(Text)
    type_x_tradeflow_id_x_transport_unit_id = Column(Text)
    created_at = Column(Text)
    calculated_size_in_kb = Column(Integer)
    tradeflow_reference = Column(Text)
    payloads = relationship("payload", backref="tradeflow")


class payload(Base):
    __tablename__ = "payload"
    id = Column(Integer, primary_key=True, autoincrement=True)
    type = Column(Text)
    has_live_data = Column(Boolean)
    predicted_at = Column(Text)
    event_date = Column(Text)
    is_final_pod = Column(Boolean)
    is_pol = Column(Boolean)
    is_transshipment_location = Column(Boolean)
    bill_of_lading_reference = Column(Text)
    booking_reference = Column(Text)
    actual = Column(Boolean)
    status_code = Column(Text)
    is_latest_actual = Column(Boolean)
    is_latest_actual_POI = Column(Boolean)
    message = Column(Text)
    transport_unit_reference = Column(Text)
    normalized_data_anomaly = Column(Integer)
    api_message_version = Column(Integer)
    tradeflow_id = Column(Integer, ForeignKey("tradeflow.id"))
    dwell_details = relationship("dwell_details", backref="payload")
    shipments = relationship("shipment", backref="payload")
    locations = relationship("location", backref="payload")
    vessels = relationship("vessel", backref="payload")
    carriers = relationship("carrier", backref="payload")
    histories = relationship("history", backref="payload")
    event_date_extended = relationship("event_date_extended", backref="payload")


class dwell_details(Base):
    __tablename__ = "dwell_details"
    id = Column(Integer, primary_key=True, autoincrement=True)
    _beta_demurrage_free_time_expires = Column(Text)
    _beta_detention_free_time_expires = Column(Text)
    payload_id = Column(Integer, ForeignKey("payload.id"))


class shipment(Base):
    __tablename__ = "shipment"
    id = Column(Integer, primary_key=True, autoincrement=True)
    is_solid = Column(Boolean)
    payload_id = Column(Integer, ForeignKey("payload.id"))
    carbon_emission_proxy_calculations = relationship(
        "carbon_emission_proxy_calculation", backref="shipment"
    )
    transport_plan_legs = relationship("transport_plan_legs", backref="shipment")
    containers = relationship("containers", backref="shipment")


class carbon_emission_proxy_calculation(Base):
    __tablename__ = "carbon_emission_proxy_calculation"
    id = Column(Integer, primary_key=True, autoincrement=True)
    result = Column(Float)
    shipment_id = Column(Integer, ForeignKey("shipment.id"))


class transport_plan_legs(Base):
    __tablename__ = "transport_plan_legs"
    id = Column(Integer, primary_key=True, autoincrement=True)
    bill_of_lading_number = Column(Text)
    booking_number = Column(Text)
    sequence_number = Column(Integer)
    shipment_id = Column(Integer, ForeignKey("shipment.id"))


class sea_shipment_legs(Base):
    __tablename__ = "sea_shipment_legs"
    id = Column(Integer, primary_key=True, autoincrement=True)
    transport_plan_legs_id = Column(Integer, ForeignKey("transport_plan_legs.id"))


class departure(Base):
    __tablename__ = "departure"
    id = Column(Integer, primary_key=True, autoincrement=True)
    type = Column(Text)
    actual = Column(Boolean)
    internal_voyage_sequence_reference = Column(Integer)
    is_final_pod = Column(Boolean)
    is_pol = Column(Boolean)
    is_transshipment_location = Column(Boolean)
    transshipment_sequence_ref = Column(Text)
    is_postpod = Column(Boolean)
    is_prepol = Column(Boolean)
    latest_provisional_reading = Column(Text)
    first_known_reading = Column(Text)
    latest_confirmed_reading = Column(Text)
    first_confirmed_reading = Column(Text)
    latest_reading = Column(Text)
    sea_shipment_legs_id = Column(Integer, ForeignKey("sea_shipment_legs.id"))
    readings_log = relationship("reading_log", backref="departure")


class arrival(Base):
    __tablename__ = "arrival"
    id = Column(Integer, primary_key=True, autoincrement=True)
    type = Column(Text)
    actual = Column(Boolean)
    internal_voyage_sequence_reference = Column(Integer)
    is_final_pod = Column(Boolean)
    is_pol = Column(Boolean)
    is_transshipment_location = Column(Boolean)
    transshipment_sequence_ref = Column(Integer)
    is_postpod = Column(Boolean)
    is_prepol = Column(Boolean)
    latest_provisional_reading = Column(Text)
    first_known_reading = Column(Text)
    latest_confirmed_reading = Column(Text)
    first_confirmed_reading = Column(Text)
    latest_reading = Column(Text)
    sea_shipment_legs_id = Column(Integer, ForeignKey("sea_shipment_legs.id"))
    latest_reading_extended = relationship("latest_reading_extended", backref="arrival")
    readings_log = relationship("reading_log", backref="arrival")


class latest_reading_extended(Base):
    __tablename__ = "latest_reading_extended"
    id = Column(Integer, primary_key=True, autoincrement=True)
    event_date_local = Column(Text)
    event_date_zulu = Column(Text)
    timezone_abbreviation = Column(Text)
    timezone_geo = Column(Text)
    timezone_utc_offset_minutes = Column(Integer)
    arrival_id = Column(Integer, ForeignKey("arrival.id"))
    departure_id = Column(Integer, ForeignKey("departure.id"))


class reading_log(Base):
    __tablename__ = "reading_log"
    id = Column(Integer, primary_key=True, autoincrement=True)
    actual = Column(Boolean)
    event_date = Column(Text)
    is_latest = Column(Boolean)
    is_latest_provisional = Column(Boolean)
    is_provisional = Column(Boolean)
    reading = Column(Text)
    arrival_id = Column(Integer, ForeignKey("arrival.id"))
    departure_id = Column(Integer, ForeignKey("departure.id"))


class carrier_transport_unit(Base):
    __tablename__ = "carrier_transport_unit"
    id = Column(Integer, primary_key=True, autoincrement=True)
    name = Column(Text)
    imo_number = Column(Text)
    mmsi_number = Column(Text)
    sea_shipment_legs_id = Column(Integer, ForeignKey("sea_shipment_legs.id"))
    arrival_id = Column(Integer, ForeignKey("arrival.id"))
    departure_id = Column(Integer, ForeignKey("departure.id"))


class containers(Base):
    __tablename__ = "containers"
    id = Column(Integer, primary_key=True, autoincrement=True)
    reference = Column(Text)
    container_length = Column(Text)
    shipment_id = Column(Integer, ForeignKey("shipment.id"))
    arrival_id = Column(Integer, ForeignKey("arrival.id"))
    departure_id = Column(Integer, ForeignKey("departure.id"))


class location(Base):
    __tablename__ = "location"
    id = Column(Integer, primary_key=True, autoincrement=True)
    unlocode = Column(Text)
    name = Column(Text)
    timezone = Column(Text)
    payload_id = Column(Integer, ForeignKey("payload.id"))
    arrival_id = Column(Integer, ForeignKey("arrival.id"))
    departure_id = Column(Integer, ForeignKey("departure.id"))
    country = relationship("country", backref="location")
    coordinates = relationship("coordinates", backref="location")


class country(Base):
    __tablename__ = "country"
    id = Column(Integer, primary_key=True, autoincrement=True)
    name = Column(Text)
    iso_a2 = Column(Text)
    location_id = Column(Integer, ForeignKey("location.id"))


class coordinates(Base):
    __tablename__ = "coordinates"
    id = Column(Integer, primary_key=True, autoincrement=True)
    lat = Column(Float)
    lng = Column(Float)
    location_id = Column(Integer, ForeignKey("location.id"))


class vessel(Base):
    __tablename__ = "vessel"
    id = Column(Integer, primary_key=True, autoincrement=True)
    name = Column(Text)
    imo_number = Column(Text)
    mmsi_number = Column(Text)
    payload_id = Column(Integer, ForeignKey("payload.id"))


class carrier(Base):
    __tablename__ = "carrier"
    id = Column(Integer, primary_key=True, autoincrement=True)
    name = Column(Text)
    payload_id = Column(Integer, ForeignKey("payload.id"))
    transport_plan_legs_id = Column(Integer, ForeignKey("transport_plan_legs.id"))
    sea_shipment_legs_id = Column(Integer, ForeignKey("sea_shipment_legs.id"))
    arrival_id = Column(Integer, ForeignKey("arrival.id"))
    departure_id = Column(Integer, ForeignKey("departure.id"))


class history(Base):
    __tablename__ = "history"
    id = Column(Integer, primary_key=True, autoincrement=True)
    event_date = Column(Text)
    actual = Column(Boolean)
    predicted_at = Column(Text)
    source = Column(Text)
    payload_id = Column(Integer, ForeignKey("payload.id"))


class event_date_extended(Base):
    __tablename__ = "event_date_extended"
    id = Column(Integer, primary_key=True, autoincrement=True)
    event_date_local = Column(Text)
    event_date_zulu = Column(Text)
    timezone_abbreviation = Column(Text)
    timezone_geo = Column(Text)
    timezone_utc_offset_minutes = Column(Integer)
    payload_id = Column(Integer, ForeignKey("payload.id"))
