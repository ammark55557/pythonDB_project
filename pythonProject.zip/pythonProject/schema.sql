IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'tradeflow')
BEGIN
	CREATE TABLE tradeflow(
		id INT PRIMARY KEY,
		hash TEXT,
		tradeflow_id INTEGER,
		type TEXT,
		message_generated_event_date TEXT,
		type_x_tradeflow_id TEXT,
		type_x_tradeflow_id_x_transport_unit_id TEXT,
		created_at TEXT,
		calculated_size_in_kb INTEGER,
		tradeflow_reference TEXT,
	)
End

IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'payload')
BEGIN
	CREATE TABLE payload(
		id INT PRIMARY KEY,
		type TEXT,
		has_live_data BIT,
		predicted_at TEXT,
		event_date TEXT,
		is_final_pod BIT,
		is_pol BIT,
		is_transshipment_location BIT,
		bill_of_lading_reference TEXT,
		booking_reference TEXT,
		actual BIT,
		status_code TEXT,
		is_latest_actual BIT,
		is_latest_actual_POI BIT,
		message TEXT,
		transport_unit_reference TEXT,
		normalized_data_anomaly INTEGER,
		api_message_version INTEGER,
		tradeflow_id INTEGER,
		FOREIGN KEY (tradeflow_id) REFERENCES tradeflow(id),
	)
End

IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'dwell_details')
BEGIN
	CREATE TABLE dwell_details(
		id INT PRIMARY KEY,
		_beta_demurrage_free_time_expires TEXT,
		_beta_detention_free_time_expires TEXT,
		payload_id INTEGER,
		FOREIGN KEY (payload_id) REFERENCES payload(id),
	)
End

IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'shipment')
BEGIN
	CREATE TABLE shipment(
		id INT PRIMARY KEY,
		is_solid BIT,
		payload_id INTEGER,
		FOREIGN KEY (payload_id) REFERENCES payload(id),
	)
End

IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'carbon_emission_proxy_calculation')
BEGIN
	CREATE TABLE carbon_emission_proxy_calculation(
		id INT PRIMARY KEY,
		result REAL,
		shipment_id INTEGER,
		FOREIGN KEY (shipment_id) REFERENCES shipment(id),
	)
End

IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'transport_plan_legs')
BEGIN
	CREATE TABLE transport_plan_legs(
		id INT PRIMARY KEY,
		bill_of_lading_number TEXT,
		booking_number TEXT,
		sequence_number INTEGER,
		shipment_id INTEGER,
		FOREIGN KEY (shipment_id) REFERENCES shipment(id),
	)
End

IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'sea_shipment_legs')
BEGIN
	CREATE TABLE sea_shipment_legs(
		id INT PRIMARY KEY,
		transport_plan_legs_id INTEGER,
		FOREIGN KEY (transport_plan_legs_id) REFERENCES transport_plan_legs(id),
	)
End

IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'departure')
BEGIN
	CREATE TABLE departure(
		id INT PRIMARY KEY,
		type TEXT,
		actual BIT,
		internal_voyage_sequence_reference INTEGER,
		is_final_pod BIT,
		is_pol BIT,
		is_transshipment_location BIT,
		transshipment_sequence_ref TEXT,
		is_postpod BIT,
		is_prepol BIT,
		latest_provisional_reading TEXT,
		first_known_reading TEXT,
		latest_confirmed_reading TEXT,
		first_confirmed_reading TEXT,
		latest_reading TEXT,
		sea_shipment_legs_id INTEGER,
		FOREIGN KEY (sea_shipment_legs_id) REFERENCES sea_shipment_legs(id),
	)
End

IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'arrival')
BEGIN
	CREATE TABLE arrival(
		id INT PRIMARY KEY,
		type TEXT,
		actual BIT,
		internal_voyage_sequence_reference INTEGER,
		is_final_pod BIT,
		is_pol BIT,
		is_transshipment_location BIT,
		transshipment_sequence_ref INTEGER,
		is_postpod BIT,
		is_prepol BIT,
		latest_provisional_reading TEXT,
		first_known_reading TEXT,
		latest_confirmed_reading TEXT,
		first_confirmed_reading TEXT,
		latest_reading TEXT,
		sea_shipment_legs_id INTEGER,
		FOREIGN KEY (sea_shipment_legs_id) REFERENCES sea_shipment_legs(id),
	)
End

IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'latest_reading_extended')
BEGIN
	CREATE TABLE latest_reading_extended(
		id INT PRIMARY KEY,
		event_date_local TEXT,
		event_date_zulu TEXT,
		timezone_abbreviation TEXT,
		timezone_geo TEXT,
		timezone_utc_offset_minutes INTEGER,
		arrival_id INTEGER,
		FOREIGN KEY (arrival_id) REFERENCES arrival(id),
		departure_id INTEGER,
		FOREIGN KEY (departure_id) REFERENCES departure(id),
	)
End

IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'reading_log')
BEGIN
	CREATE TABLE reading_log(
		id INT PRIMARY KEY,
		actual BIT,
		event_date TEXT,
		is_latest BIT,
		is_latest_provisional BIT,
		is_provisional BIT,
		reading TEXT,
		arrival_id INTEGER,
		FOREIGN KEY (arrival_id) REFERENCES arrival(id),
		departure_id INTEGER,
		FOREIGN KEY (departure_id) REFERENCES departure(id),
	)
End

IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'carrier_transport_unit')
BEGIN
	CREATE TABLE carrier_transport_unit(
		id INT PRIMARY KEY,
		name TEXT,
		imo_number TEXT,
		mmsi_number TEXT,
		sea_shipment_legs_id INTEGER,
		FOREIGN KEY (sea_shipment_legs_id) REFERENCES sea_shipment_legs(id),
		arrival_id INTEGER,
		FOREIGN KEY (arrival_id) REFERENCES arrival(id),
		departure_id INTEGER,
		FOREIGN KEY (departure_id) REFERENCES departure(id),
	)
End

IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'containers')
BEGIN
	CREATE TABLE containers(
		id INT PRIMARY KEY,
		reference TEXT,
		container_length TEXT,
		shipment_id INTEGER,
		FOREIGN KEY (shipment_id) REFERENCES shipment(id),
		arrival_id INTEGER,
		FOREIGN KEY (arrival_id) REFERENCES arrival(id),
		departure_id INTEGER,
		FOREIGN KEY (departure_id) REFERENCES departure(id),
	)
End

IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'location')
BEGIN
	CREATE TABLE location(
		id INT PRIMARY KEY,
		unlocode TEXT,
		name TEXT,
		timezone TEXT,
		payload_id INTEGER,
		FOREIGN KEY (payload_id) REFERENCES payload(id),
		arrival_id INTEGER,
		FOREIGN KEY (arrival_id) REFERENCES arrival(id),
		departure_id INTEGER,
		FOREIGN KEY (departure_id) REFERENCES departure(id),
	)
End

IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'country')
BEGIN
	CREATE TABLE country(
		id INT PRIMARY KEY,
		name TEXT,
		iso_a2 TEXT,
		location_id INTEGER,
		FOREIGN KEY (location_id) REFERENCES location(id),
	)
End

IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'coordinates')
BEGIN
	CREATE TABLE coordinates(
		id INT PRIMARY KEY,
		lat REAL,
		lng REAL,
		location_id INTEGER,
		FOREIGN KEY (location_id) REFERENCES location(id),
	)
End

IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'vessel')
BEGIN
	CREATE TABLE vessel(
		id INT PRIMARY KEY,
		name TEXT,
		imo_number TEXT,
		mmsi_number TEXT,
		payload_id INTEGER,
		FOREIGN KEY (payload_id) REFERENCES payload(id),
	)
End

IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'carrier')
BEGIN
	CREATE TABLE carrier(
		id INT PRIMARY KEY,
		name TEXT,
		payload_id INTEGER,
		FOREIGN KEY (payload_id) REFERENCES payload(id),
		transport_plan_legs_id INTEGER,
		FOREIGN KEY (transport_plan_legs_id) REFERENCES transport_plan_legs(id),
		sea_shipment_legs_id INTEGER,
		FOREIGN KEY (sea_shipment_legs_id) REFERENCES sea_shipment_legs(id),
		arrival_id INTEGER,
		FOREIGN KEY (arrival_id) REFERENCES arrival(id),
		departure_id INTEGER,
		FOREIGN KEY (departure_id) REFERENCES departure(id),
	)
End

IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'history')
BEGIN
	CREATE TABLE history(
		id INT PRIMARY KEY,
		event_date TEXT,
		actual BIT,
		predicted_at TEXT,
		source TEXT,
		payload_id INTEGER,
		FOREIGN KEY (payload_id) REFERENCES payload(id),
	)
End

IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'event_date_extended')
BEGIN
	CREATE TABLE event_date_extended(
		id INT PRIMARY KEY,
		event_date_local TEXT,
		event_date_zulu TEXT,
		timezone_abbreviation TEXT,
		timezone_geo TEXT,
		timezone_utc_offset_minutes INTEGER,
		payload_id INTEGER,
		FOREIGN KEY (payload_id) REFERENCES payload(id),
	)
End

